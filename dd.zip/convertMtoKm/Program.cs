﻿using System;

namespace poundToDollar
{
    class Program
    {
        static void Main(string[] args)
        {

            char ch = ']';

            Console.WriteLine((int)ch);

        }
    }
}
