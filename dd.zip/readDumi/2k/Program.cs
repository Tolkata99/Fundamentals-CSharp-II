﻿using System;

namespace _2k
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int k = 0;

            while (k <= n)
            {
                double bank = double.Parse(Console.ReadLine());
               

            }
            Console.WriteLine(k);
        }
    }
}
