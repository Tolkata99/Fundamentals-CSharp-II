﻿using System;
using System.Linq;

Console.WriteLine("open");
