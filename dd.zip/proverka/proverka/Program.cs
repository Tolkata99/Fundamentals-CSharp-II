﻿using System;

namespace proverka
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 6)
            {
                i++;
            
            if (i % 2 == 0)
                Console.WriteLine(i);
            }
        }
         
    }
}
