﻿using System;

namespace COINS
{
    class Program
    {
        static void Main(string[] args)
        {
            double change = double.Parse(Console.ReadLine());
            double count = 0;
            double changeInCoins = Math.Floor(change * 100);

            while (changeInCoins != 0)
            {
                if(changeInCoins >= 200)
                {
                    changeInCoins -= 200;
                    count++;
                }
                else if(changeInCoins >= 100)
                {
                    changeInCoins -= 100;
                    count++;

                }
                else if (changeInCoins >= 50)
                {
                    changeInCoins -= 50;
                    count++;
                }

                else if (changeInCoins >= 20)
                {
                    changeInCoins -= 20;
                    count++;
                }
                else if (changeInCoins >= 10)
                {
                    changeInCoins -= 10;
                    count++;
                }
                else if (changeInCoins >= 5)
                {
                    changeInCoins -= 5;
                    count++;
                }
                else if (changeInCoins >= 2)
                {
                    changeInCoins -= 2;
                    count++;
                }
                else if (changeInCoins >= 1)
                {
                    changeInCoins -= 1;
                    count++;
                }
                



            }
            Console.WriteLine(count);
        }
    }
}
